package hw180123;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@AllArgsConstructor
@Getter
@Setter
@ToString

public class Card  implements Serializable {
    private  long number;
    private String name;
    private String lastName;
    private int month;
    private int year;
    private int CVV;



        public void cartPrint() {
            System.out.printf("number : %-20d\t nameandsurname : %-5s %-20s\t cvv : %3d\t card expiry date : %02d/%d\n", number,name,lastName, CVV,month,year);
        }

    }






