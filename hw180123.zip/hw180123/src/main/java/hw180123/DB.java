package hw180123;

import java.util.ArrayList;
import java.util.List;

public class DB {

    private final List<Card> dBCard;

    public DB() {
        this.dBCard = new ArrayList<>();
    }

    public void add(Card card) {
        dBCard.add(card);
    }

    public void remove(Card card) {
        dBCard.remove(card);
    }

    public List<Card> getdBCard(){
        return dBCard;
    }

}
