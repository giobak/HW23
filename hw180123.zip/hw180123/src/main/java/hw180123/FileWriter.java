package hw180123;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.List;

public class FileWriter {
    public void writer(String fileName, List<String> ls) {
        try (BufferedWriter writer = new BufferedWriter(new java.io.FileWriter(fileName))) {
            for (String str: ls) {
                writer.write(str);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
