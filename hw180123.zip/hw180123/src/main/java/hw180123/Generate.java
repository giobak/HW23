package hw180123;

import com.github.javafaker.Faker;

import java.time.LocalDate;
import java.util.Random;

public class Generate {
    Random random = new Random();
    Faker faker = new Faker();

    public long generateNumber(){
        long number = random.nextInt(12) + 1;
        for (int i = 0; i < 16; i++) {
            number = (long) (number*10 +random.nextInt(10));
        }
        return number;
    }

    public String generateName() {
        return faker.name().name();
    }

    public String generateLastName() {
        return faker.name().lastName();
    }

    public int generateMonth(){
        return random.nextInt(1,13);
    }

    public int generateYear(){
        LocalDate localDate = LocalDate.now();
        return localDate.getYear() % 100 + random.nextInt(1,6);
    }

    public int generateCVV(){
        return random.ints(100, 1000)
                .findFirst()
                .getAsInt();
    }


}
