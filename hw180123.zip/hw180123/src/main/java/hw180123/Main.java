package hw180123;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Generate generate = new Generate();
        DB db = new DB();
        for (int i = 0; i < 10; i++) {
            db.add(new Card(generate.generateNumber(), generate.generateName(), generate.generateLastName(), generate.generateMonth(), generate.generateYear(), generate.generateCVV()));
        }
        List<Card> listCard = db.getdBCard();
        for (Card card: listCard) {
            card.cartPrint();
        }

        OneLine oneLine = new OneLine();
        List<String> OneLineOutput = new ArrayList<>();
        listCard.forEach(card -> OneLineOutput.add(oneLine.setAllInOneLine(card)));

        FileWriter fileWriter = new FileWriter();
        fileWriter.writer("file1", OneLineOutput);

        FileReader fileReader = new FileReader();
        List<String> OneLineInput= fileReader.reader("file1");
        //OneLineInput = fileReader.reader("file1");

        DataParsing dataParsing = new DataParsing();
        dataParsing.parse(OneLineOutput);
        dataParsing.listOutput.forEach(System.out::println);
    }
}
