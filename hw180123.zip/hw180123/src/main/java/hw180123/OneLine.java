package hw180123;

import lombok.Getter;

@Getter

public class OneLine {

    public String setAllInOneLine(Card card) {
        return card.getNumber() +
                card.getName() +
                card.getLastName() +
                card.getMonth() +
                card.getYear() +
                card.getCVV();
    }


    }

